package com.ktdsuniversity.edu.mv.rtng.service;

import com.ktdsuniversity.edu.mv.rtng.dao.RtngDAO;
import com.ktdsuniversity.edu.mv.rtng.dao.RtngDAOImpl;
import com.ktdsuniversity.edu.mv.rtng.vo.RtngVO;

public class RtngServiceImpl implements RtngService {
	
	private RtngDAO rtngDAO;
	
	public RtngServiceImpl() {
		rtngDAO = new RtngDAOImpl();
	}
	
	@Override
	public boolean createRtngDAO(RtngVO rtngVO) {
		int insertCount = rtngDAO.createRtngDAO(rtngVO);
		return insertCount > 0;
	}

	@Override
	public boolean updateRtngDAO(RtngVO rtngVO) {
		return rtngDAO.updateRtngDAO(rtngVO) > 0;
	}

}
