package com.ktdsuniversity.edu.mv.rtng.vo;


public class RtngVO {

	private String rtngId;
	private String mvId;
	private int rtng;
	private String rtngCntnt;
	private String rtngWrtr;
	private String rtngRgstTm;
	private int lkcnt;
	private int dslkCnt;
	
	public String getRtngId() {
		return rtngId;
	}
	public void setRtngId(String rtngId) {
		this.rtngId = rtngId;
	}
	public String getMvId() {
		return mvId;
	}
	public void setMvId(String mvId) {
		this.mvId = mvId;
	}
	public int getRtng() {
		return rtng;
	}
	public void setRtng(int rtng) {
		this.rtng = rtng;
	}
	public String getRtngCntnt() {
		return rtngCntnt;
	}
	public void setRtngCntnt(String rtngCntnt) {
		this.rtngCntnt = rtngCntnt;
	}
	public String getRtngWrtr() {
		return rtngWrtr;
	}
	public void setRtngWrtr(String rtngWrtr) {
		this.rtngWrtr = rtngWrtr;
	}
	public String getRtngRgstTm() {
		return rtngRgstTm;
	}
	public void setRtngRgstTm(String rtngRgstTm) {
		this.rtngRgstTm = rtngRgstTm;
	}
	public int getLkcnt() {
		return lkcnt;
	}
	public void setLkcnt(int lkcnt) {
		this.lkcnt = lkcnt;
	}
	public int getDslkCnt() {
		return dslkCnt;
	}
	public void setDslkCnt(int dslkCnt) {
		this.dslkCnt = dslkCnt;
	}
	
	
}
