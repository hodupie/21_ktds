package com.ktdsuniversity.edu.mv.ntn.vo;

public class NtnVO {
	/**
	 * 국가ID
	 */
	private int ntnId;
	
	/**
	 * 국가명
	 */
	private String ntnNm;
	
	public int getNtnId() {
		return ntnId;
	}
	public void setNtnId(int ntnId) {
		this.ntnId = ntnId;
	}
	public String getNtnNm() {
		return ntnNm;
	}
	public void setNtnNm(String ntnNm) {
		this.ntnNm = ntnNm;
	}
}
