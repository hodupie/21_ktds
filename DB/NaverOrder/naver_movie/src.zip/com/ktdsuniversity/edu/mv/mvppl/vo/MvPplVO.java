package com.ktdsuniversity.edu.mv.mvppl.vo;

public class MvPplVO {
	
	/**
	 * 영화인ID
	 */
	private String mvPplId;
	
	/**
	 * 프로필사진
	 */
	private String prflPht;
	
	/**
	 * 이름
	 */
	private String nm;
	
	/**
	 * 본명
	 */
	private String rlNm;
	
	public String getMvPplId() {
		return mvPplId;
	}
	public void setMvPplId(String mvPplId) {
		this.mvPplId = mvPplId;
	}
	public String getPrflPht() {
		return prflPht;
	}
	public void setPrflPht(String prflPht) {
		this.prflPht = prflPht;
	}
	public String getNm() {
		return nm;
	}
	public void setNm(String nm) {
		this.nm = nm;
	}
	public String getRlNm() {
		return rlNm;
	}
	public void setRlNm(String rlNm) {
		this.rlNm = rlNm;
	}
	
	
}
