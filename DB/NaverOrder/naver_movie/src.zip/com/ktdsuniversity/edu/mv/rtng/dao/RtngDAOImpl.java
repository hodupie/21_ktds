package com.ktdsuniversity.edu.mv.rtng.dao;

import com.ktdsuniversity.edu.mv.rtng.vo.RtngVO;
import com.ktdsuniversity.edu.mv.util.db.AbstractDaoPoolSupport;

public class RtngDAOImpl extends AbstractDaoPoolSupport<RtngVO> implements RtngDAO {

	@Override
	public int createRtngDAO(RtngVO rtngVO) {
		StringBuffer query = new StringBuffer();
		query.append(" INSERT INTO RTNG ");
		query.append("  (RTNG_ID        ");
		query.append(" , MV_ID          ");
		query.append(" , RTNG           ");
		query.append(" , RTNG_CNTNT     ");
		query.append(" , RTNG_WRTR      ");
		query.append(" , RTNG_RGST_TM   ");
		query.append(" , LK_CNT         ");
		query.append(" , DSLK_CNT)      ");
		query.append(" VALUES           ");
		query.append("  ('MR-' || TO_CHAR(SYSDATE, 'YYYYMMDD') || '-' || LPAD(SEQ_RTNG_PK.NEXTVAL, 5, '0') ");
		query.append(" , ?              ");
		query.append(" , ?              ");
		query.append(" , ?              ");
		query.append(" , ?              ");
		query.append(" , SYSDATE        ");
		query.append(" , ?              ");
		query.append(" , ?)             ");
		
		
		return super.insert(query.toString(), (pstmt) -> {
			pstmt.setString(1, rtngVO.getMvId());
			pstmt.setInt(2, rtngVO.getRtng());
			pstmt.setString(3, rtngVO.getRtngCntnt());
			pstmt.setString(4, rtngVO.getRtngWrtr());
			pstmt.setInt(5, rtngVO.getLkcnt());
			pstmt.setInt(6, rtngVO.getDslkCnt());
		});
	}

	@Override
	public int updateRtngDAO(RtngVO rtngVO) {
		StringBuffer query = new StringBuffer();
		query.append(" UPDATE RTNG             ");
		query.append("    SET RTNG = ?         ");
		query.append("      , RTNG_CNTNT = ?   ");
		query.append("  WHERE RTNG_ID = ?      ");

		return super.update(query.toString(), (pstmt) -> {
			pstmt.setInt(1, rtngVO.getRtng());
			pstmt.setString(2, rtngVO.getRtngCntnt());
			pstmt.setString(3, rtngVO.getRtngId());
		});
	}

}
