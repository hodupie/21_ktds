package com.ktdsuniversity.edu.mv;

import java.util.ArrayList;
import java.util.List;

import com.ktdsuniversity.edu.mv.cmmncd.service.CmmnCdService;
import com.ktdsuniversity.edu.mv.cmmncd.service.CmmnCdServiceImpl;
import com.ktdsuniversity.edu.mv.cmmncd.vo.CmmnCdVO;
import com.ktdsuniversity.edu.mv.cmpn.service.CmpnService;
import com.ktdsuniversity.edu.mv.cmpn.service.CmpnServiceImpl;
import com.ktdsuniversity.edu.mv.cmpn.vo.CmpnVO;
import com.ktdsuniversity.edu.mv.fmsln.service.FmsLnService;
import com.ktdsuniversity.edu.mv.fmsln.service.FmsLnServiceImpl;
import com.ktdsuniversity.edu.mv.fmsln.vo.FmsLnVO;
import com.ktdsuniversity.edu.mv.gnr.controller.GnrController;
import com.ktdsuniversity.edu.mv.gnr.service.GnrService;
import com.ktdsuniversity.edu.mv.gnr.service.GnrServiceImpl;
import com.ktdsuniversity.edu.mv.gnr.vo.GnrVO;
import com.ktdsuniversity.edu.mv.mv.service.MvService;
import com.ktdsuniversity.edu.mv.mv.service.MvServiceImpl;
import com.ktdsuniversity.edu.mv.mv.vo.MvVO;
import com.ktdsuniversity.edu.mv.mv.vo.PrdcPrtcptnCmpnVO;
import com.ktdsuniversity.edu.mv.mv.vo.PrdcPrtcptnPplVO;
import com.ktdsuniversity.edu.mv.mvppl.service.MvPplService;
import com.ktdsuniversity.edu.mv.mvppl.service.MvPplServiceImpl;
import com.ktdsuniversity.edu.mv.mvppl.vo.MvPplVO;
import com.ktdsuniversity.edu.mv.ntn.service.NtnService;
import com.ktdsuniversity.edu.mv.ntn.service.NtnServiceImpl;
import com.ktdsuniversity.edu.mv.ntn.vo.NtnVO;
import com.ktdsuniversity.edu.mv.pht.service.PhtService;
import com.ktdsuniversity.edu.mv.pht.service.PhtServiceImpl;
import com.ktdsuniversity.edu.mv.pht.vo.PhtVO;
import com.ktdsuniversity.edu.mv.rtng.service.RtngService;
import com.ktdsuniversity.edu.mv.rtng.service.RtngServiceImpl;
import com.ktdsuniversity.edu.mv.rtng.vo.RtngVO;
import com.ktdsuniversity.edu.mv.vd.service.VdService;
import com.ktdsuniversity.edu.mv.vd.service.VdServiceImpl;
import com.ktdsuniversity.edu.mv.vd.vo.VdVO;

public class NaverMv implements GnrController{
//	private void gnr(GnrService gnrService) {
//		createGnr(gnrService, getNextLine("장르 이름 넣으셈"));
//		deleteGnr(gnrService, getNextInt("지울 id 넣어"));
//		readAllGnr(gnrService);
//		updateGnr(gnrService, getNextInt("수정 아이디"), getNextLine("수정 내용"));
//	}
	public static void main(String[] args){
		NaverMv nm = new NaverMv();
		boolean createResult = false;
		
		GnrService gnrService = new GnrServiceImpl();
		GnrVO gnrVO = new GnrVO();
//		gnrVO.setGnrNm("범죄");
//		createResult = gnrService.createGnr(gnrVO);
//		System.out.println("범죄 장르 등록 " + createResult);
//		
		NtnService ntnService = new NtnServiceImpl();
		NtnVO ntnVO = new NtnVO();
//		ntnVO.setNtnNm("대한민국");
//		createResult = ntnService.createNtn(ntnVO);
//		System.out.println("대한민국 국가 등록 " + createResult);
//		
		MvPplService mvPplService = new MvPplServiceImpl();
		MvPplVO mvPplVO = new MvPplVO();
//		mvPplVO.setPrflPht("Profile Photo URL");
//		mvPplVO.setNm("최지영");
//		mvPplVO.setRlNm(null);
//		createResult = mvPplService.createMyPpl(mvPplVO);
//		System.out.println("최지영 영화인 등록 " + createResult);
//		
		CmpnService cmpnService = new CmpnServiceImpl();
		CmpnVO cmpnVO = new CmpnVO();
//		cmpnVO.setCmpnNm("(주)누리픽쳐스");
//		createResult = cmpnService.createCmpn(cmpnVO);
//		System.out.println("(주)누리픽쳐스 회사 등록 " + createResult);
//		
		CmmnCdService cmmnCdService = new CmmnCdServiceImpl();
		CmmnCdVO cmmnCdVO = new CmmnCdVO();
//		cmmnCdVO.setCdId("001");
//		cmmnCdVO.setCdNm("상영상태");
//		cmmnCdVO.setPrcdncCdId(null);
//		createResult = cmmnCdService.createCmmnCd(cmmnCdVO);
//		System.out.println("001 상영상태 회사 등록 " + createResult);
		
		MvService mvService = new MvServiceImpl();
		MvVO mvVO = new MvVO();
		mvVO.setMvTtl("새로운 영화");
		mvVO.setEngTtl("New Movie");
		mvVO.setScrnStt("001_01");
		mvVO.setScrnTm(120);
		mvVO.setOpngDt("20230308");
		mvVO.setGrd("002_04");
		mvVO.setPstr("URL");
		mvVO.setSmr("줄거리");
		
		List<GnrVO> gnrList = new ArrayList<>();
//		GnrVO gnrVO = new GnrVO();
		gnrVO.setGnrId(2);
		gnrList.add(gnrVO);
		mvVO.setGnrList(gnrList);
		
		List<NtnVO> ntnList = new ArrayList<>();
//		NtnVO ntnVO = new NtnVO();
		ntnVO.setNtnId(2);
		ntnList.add(ntnVO);
		mvVO.setNtnList(ntnList);
		
		List<PrdcPrtcptnCmpnVO> cmpnList = new ArrayList<>();
		PrdcPrtcptnCmpnVO prdcPrtcptnCmpnVO = new PrdcPrtcptnCmpnVO();
		prdcPrtcptnCmpnVO.setCmpnId("CO-20230308-00002");
		prdcPrtcptnCmpnVO.setDstrbtn("006_001");
		cmpnList.add(prdcPrtcptnCmpnVO);
		
		prdcPrtcptnCmpnVO.setCmpnId("CO-20230308-00002");
		prdcPrtcptnCmpnVO.setDstrbtn("006_002");
		cmpnList.add(prdcPrtcptnCmpnVO);

		mvVO.setCmpnList(cmpnList);
		
		List<PrdcPrtcptnPplVO> mvPplList = new ArrayList<>();
		PrdcPrtcptnPplVO prdcPrtcptnPplVO = new PrdcPrtcptnPplVO();
		prdcPrtcptnPplVO.setMvPplId("PD-20230308-00006");
		prdcPrtcptnPplVO.setRol("005_02");
		prdcPrtcptnPplVO.setDtlRol(null);
		mvPplList.add(prdcPrtcptnPplVO);
		mvVO.setMvPplList(mvPplList);
		
//		mvService.createMv(mvVO);
		
		PhtService phtService = new PhtServiceImpl();
		PhtVO phtVO = new PhtVO();
//		phtVO.setMvId("MV-20230309-00030");
//		phtVO.setPhtTp("003_01");
//		phtVO.setThmbnlPht("URL");
//		phtVO.setOrgnlPht("OriginalPhoto");
//		createResult = phtService.createPht(phtVO);
//		System.out.println("사진 등록 " + createResult);
//		
		VdService vdService = new VdServiceImpl();
		VdVO vdVO = new VdVO();
//		vdVO.setMvId("MV-20230309-00030");
//		vdVO.setVdTp("004_01");
//		vdVO.setVdTtl("리뷰 예고편");
//		vdVO.setThmbnl("URL");
//		vdVO.setVdUrl("Video Url");
//		createResult = vdService.creatdVd(vdVO);
//		System.out.println("동영상 등록 " + createResult);
//		
		RtngService rtngService = new RtngServiceImpl();
		RtngVO rtngVO = new RtngVO();
//		rtngVO.setMvId("MV-20230309-00030");
//		rtngVO.setRtng(3);
//		rtngVO.setRtngCntnt("이거 본 걸 비밀로 해야돼서 대외비임");
//		rtngVO.setRtngWrtr("kkkk");
//		rtngVO.setLkcnt(615);
//		rtngVO.setDslkCnt(79);
//		createResult = rtngService.createRtngDAO(rtngVO);
//		System.out.println("평점 등록 " + createResult);
//		
		FmsLnService fmsLnService = new FmsLnServiceImpl();
		FmsLnVO fmsLnVO = new FmsLnVO();
//		fmsLnVO.setMvId("MV-20230309-00030");
//		fmsLnVO.setMvPplId("PD-20230308-00006");
//		fmsLnVO.setFmsLn("예수님입니다, 부활 하셨거든");
//		fmsLnVO.setXplntn(null);
//		fmsLnVO.setRgstPplNm("yoog");
//		createResult = fmsLnService.createFmsLn(fmsLnVO);
//		System.out.println("명대사 등록 " + createResult);
		
		gnrVO.setGnrId(2);
		gnrVO.setGnrNm("스릴러");
//		gnrService.updateGnr(gnrVO);
		
		cmpnVO.setCmpnId("CO-20230308-00002");
		cmpnVO.setCmpnNm("유니버설 픽쳐스");
//		cmpnService.updateCmpn(cmpnVO);
		
		mvPplVO.setPrflPht("URL");
		mvPplVO.setNm("호두");
		mvPplVO.setMvPplId("PD-20230308-00006");
//		mvPplService.updateMyPpl(mvPplVO);
		
		ntnVO.setNtnId(2);
		ntnVO.setNtnNm("프랑스");
//		ntnService.updateNtn(ntnVO);
		
		phtVO.setPhtTp("003_10");
		phtVO.setThmbnlPht("URL");
		phtVO.setOrgnlPht("원본사진");
		phtVO.setPhtId("PT-20230309-00001");
//		phtService.updatePht(phtVO);
		
		rtngVO.setRtng(5);
		rtngVO.setRtngCntnt("정말 재미있어요!");
		rtngVO.setRtngId("MR-20230309-00001");
		rtngService.updateRtngDAO(rtngVO);
		
		
	}
}
