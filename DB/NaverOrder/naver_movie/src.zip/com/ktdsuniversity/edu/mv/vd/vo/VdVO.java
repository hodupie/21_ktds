package com.ktdsuniversity.edu.mv.vd.vo;

public class VdVO {
	private String vdId;
	private String mvId;
	private String vdTp;
	private String vdTtl;
	private String thmbnl;
	private int vdPlyCnt;
	private String vdUrl;
	private String rgstDt;
	
	public String getVdId() {
		return vdId;
	}
	public void setVdId(String vdId) {
		this.vdId = vdId;
	}
	public String getMvId() {
		return mvId;
	}
	public void setMvId(String mvId) {
		this.mvId = mvId;
	}
	public String getVdTp() {
		return vdTp;
	}
	public void setVdTp(String vdTp) {
		this.vdTp = vdTp;
	}
	public String getVdTtl() {
		return vdTtl;
	}
	public void setVdTtl(String vdTtl) {
		this.vdTtl = vdTtl;
	}
	public String getThmbnl() {
		return thmbnl;
	}
	public void setThmbnl(String thmbnl) {
		this.thmbnl = thmbnl;
	}
	public int getVdPlyCnt() {
		return vdPlyCnt;
	}
	public void setVdPlyCnt(int vdPlyCnt) {
		this.vdPlyCnt = vdPlyCnt;
	}
	public String getVdUrl() {
		return vdUrl;
	}
	public void setVdUrl(String vdUrl) {
		this.vdUrl = vdUrl;
	}
	public String getRgstDt() {
		return rgstDt;
	}
	public void setRgstDt(String rgstDt) {
		this.rgstDt = rgstDt;
	}
	
	
}
