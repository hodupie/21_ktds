package com.ktdsuniversity.edu.mv.mv.vo;

import com.ktdsuniversity.edu.mv.cmpn.vo.CmpnVO;

/**
 * 제작참여회사
 * @author User
 *
 */
public class PrdcPrtcptnCmpnVO extends CmpnVO {
	
	private String Dstrbtn;

	public String getDstrbtn() {
		return Dstrbtn;
	}

	public void setDstrbtn(String dstrbtn) {
		Dstrbtn = dstrbtn;
	}

}
