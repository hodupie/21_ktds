package com.ktdsuniversity.edu.mv.pht.vo;

public class PhtVO {
	private String phtId;
	private String mvId;
	private String phtTp;
	private String thmbnlPht;
	private String orgnlPht;
	
	public String getPhtId() {
		return phtId;
	}
	public void setPhtId(String phtId) {
		this.phtId = phtId;
	}
	public String getMvId() {
		return mvId;
	}
	public void setMvId(String mvId) {
		this.mvId = mvId;
	}
	public String getPhtTp() {
		return phtTp;
	}
	public void setPhtTp(String phtTp) {
		this.phtTp = phtTp;
	}
	public String getThmbnlPht() {
		return thmbnlPht;
	}
	public void setThmbnlPht(String thmbnlPht) {
		this.thmbnlPht = thmbnlPht;
	}
	public String getOrgnlPht() {
		return orgnlPht;
	}
	public void setOrgnlPht(String orgnlPht) {
		this.orgnlPht = orgnlPht;
	}
	
	
}
