package com.ktdsuniversity.edu.mv.mv.dao;

import com.ktdsuniversity.edu.mv.mv.vo.MvVO;

public interface MvDAO {
	
	/**
	 * 영화의 새로운 PK(ID)를 발급받는다
	 * @return 영화의 새로운 ID
	 */
	public String createNewMvId();
	
	/**
	 * 영화 데이터 등록 (영화 테이블에 있는 컬럼의 정보만 등록)
	 * @param mvVO
	 * @return
	 */
	public int createMv(MvVO mvVO);
}
