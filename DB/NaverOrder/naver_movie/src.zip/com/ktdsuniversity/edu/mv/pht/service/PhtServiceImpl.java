package com.ktdsuniversity.edu.mv.pht.service;

import java.util.List;

import com.ktdsuniversity.edu.mv.pht.dao.PhtDAO;
import com.ktdsuniversity.edu.mv.pht.dao.PhtDAOImpl;
import com.ktdsuniversity.edu.mv.pht.vo.PhtVO;

public class PhtServiceImpl implements PhtService {
	
	private PhtDAO phtDAO;
	
	public PhtServiceImpl() {
		phtDAO = new PhtDAOImpl();
	}

	@Override
	public boolean createPht(PhtVO phtVO) {
		int insertCount = phtDAO.createPht(phtVO);
		return insertCount > 0;
	}

	@Override
	public List<PhtVO> readAllPht() {
		return null;
	}

	@Override
	public boolean updatePht(PhtVO phtVO) {
		return phtDAO.updatePht(phtVO) > 0;
	}

	@Override
	public boolean deletePht(int phtId) {
		return false;
	}

}
