package com.ktdsuniversity.edu.mv.cmmncd.vo;

public class CmmnCdVO {
	
	/**
	 * 코드ID
	 */
	private String cdId;
	
	/**
	 * 코드명
	 */
	private String cdNm;
	
	/**
	 * 상위코드ID
	 */
	private String prcdncCdId;
	
	public String getCdId() {
		return cdId;
	}
	public void setCdId(String cdId) {
		this.cdId = cdId;
	}
	public String getCdNm() {
		return cdNm;
	}
	public void setCdNm(String cdNm) {
		this.cdNm = cdNm;
	}
	public String getPrcdncCdId() {
		return prcdncCdId;
	}
	public void setPrcdncCdId(String prcdncCdId) {
		this.prcdncCdId = prcdncCdId;
	}

}
