package com.ktdsuniversity.edu.mv.cmpn.vo;

public class CmpnVO {
	
	/**
	 * 회사ID
	 */
	private String cmpnId;
	
	/**
	 * 회사명
	 */
	private String cmpnNm;
	
	public String getCmpnId() {
		return cmpnId;
	}
	public void setCmpnId(String cmpnId) {
		this.cmpnId = cmpnId;
	}
	public String getCmpnNm() {
		return cmpnNm;
	}
	public void setCmpnNm(String cmpnNm) {
		this.cmpnNm = cmpnNm;
	}
	
	

}
