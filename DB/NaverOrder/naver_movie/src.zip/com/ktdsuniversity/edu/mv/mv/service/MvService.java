package com.ktdsuniversity.edu.mv.mv.service;

import com.ktdsuniversity.edu.mv.mv.vo.MvVO;

public interface MvService {
	
	/**
	 * 영화 데이터 등록
	 * @param mvVO
	 * @return 데이터 등록 결과
	 */
	public boolean createMv(MvVO mvVO);
	
	/**
	 * 영화 데이터 수정
	 * @param mvVO
	 * @return 데이터 수정 결과
	 */
	public boolean updateMv(MvVO mvVO);
	
	

}
